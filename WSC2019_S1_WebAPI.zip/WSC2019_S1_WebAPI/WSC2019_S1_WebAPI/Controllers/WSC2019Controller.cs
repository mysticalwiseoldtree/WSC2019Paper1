﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WSC2019_S1_WebAPI.Models;

namespace WSC2019_S1_WebAPI.Controllers
{

    [ApiController]
    [Route("api/[controller]")]
    public class WSC2019Controller : ControllerBase
    {

        [HttpGet("AllAssets")]
        public IActionResult GetAllAsset()
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var allAssets = db.Assets.Select(x => new
                    {
                        x.Id,
                        x.AssetName,
                        AssetGroup = x.AssetGroup.Name,
                        DepartmentName = x.DepartmentLocation.Department.Name,
                        x.AssetSn
                    }).ToList();

                    if (allAssets != null)
                    {
                        return Ok(allAssets);
                    }
                    else
                    {
                        return StatusCode(401, "Cannot get assets");
                    }
                }
                catch (Exception ex)
                {
                    return StatusCode(401, "Cannot");
                }
            }
        }

        private string AssetSNCalculation(string departmentName, string assetGroupName)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                { // Step 1: Retrieve the department ID and asset group ID
                    var department = db.Departments
                                       .FirstOrDefault(d => d.Name == departmentName);
                    if (department == null)
                    {
                        throw new Exception("Invalid department");
                    }

                    var assetGroup = db.AssetGroups
                                       .FirstOrDefault(ag => ag.Name == assetGroupName);
                    if (assetGroup == null)
                    {
                        throw new Exception("Invalid asset group");
                    }

                    // Step 2: Retrieve the latest serial number (nnnn) for the given department and asset group
                    var lastAsset = db.Assets
                                      .Where(a => a.DepartmentLocation.DepartmentId == department.Id && a.AssetGroupId == assetGroup.Id)
                                      .OrderByDescending(a => a.AssetSn)
                                      .FirstOrDefault();

                    // Step 3: Determine the next serial number (nnnn)
                    int lastSerialNumber = 0;
                    if (lastAsset != null && lastAsset.AssetSn.Length >= 8)
                    {
                        // Extract the last 4 digits (nnnn) from the existing asset serial number
                        lastSerialNumber = int.Parse(lastAsset.AssetSn.Substring(6, 4)); // Extract "nnnn"
                    }

                    // Increment the serial number for the new asset
                    int newSerialNumber = lastSerialNumber + 1;

                    // Step 4: Format the components with leading zeros
                    var dd = department.Id.ToString().PadLeft(2, '0');   // Ensure department ID is 2 digits
                    var gg = assetGroup.Id.ToString().PadLeft(2, '0');   // Ensure asset group ID is 2 digits
                    var nnnn = newSerialNumber.ToString().PadLeft(4, '0'); // Ensure serial number is 4 digits

                    // Step 5: Create the SN in the format dd/gg/nnnn
                    var SNnumber = $"{dd}/{gg}/{nnnn}";
                    return SNnumber;
                }
                catch (Exception ex)
                {
                    return "";
                }
            }
        }

        [HttpGet("AllEmp")]
        public IActionResult GetEmployee()
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var allEmp = db.Employees.Select(x => new
                    {
                        x.Id,
                        x.FirstName,
                        x.LastName
                    }).ToList();

                    return Ok(allEmp);
                }
                catch (Exception ex)
                {
                    return StatusCode(401, $"Cannot create, {ex.Message}");
                }
            }
        }

        [HttpGet("AllDeptLoc")]
        public IActionResult GetLocation(int deptId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    // Log deptId to ensure correct value is passed
                    Console.WriteLine($"Received deptId: {deptId}");

                    // Include Location to ensure it's loaded
                    var allLoc = db.DepartmentLocations
                                   .Where(x => x.DepartmentId == deptId)
                                   .Select(x => new
                                   {
                                       deptLocId = x.Id,
                                       x.Location.Name
                                   })
                                   .ToList();

                    // Log the result count to ensure data is being retrieved
                    Console.WriteLine($"Number of locations found: {allLoc.Count}");

                    return Ok(allLoc);
                }
                catch (Exception ex)
                {
                    return StatusCode(401, $"Cannot create, {ex.Message}");
                }
            }
        }


        [HttpGet("AllAssetGroup")]
        public IActionResult GetAssGrp()
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var allAG = db.AssetGroups.Select(x => new
                    {
                        x.Id,
                        x.Name
                    }).ToList();

                    return Ok(allAG);
                }
                catch (Exception ex)
                {
                    return StatusCode(401, $"Cannot create, {ex.Message}");
                }
            }
        }

        [HttpGet("AllDept")]
        public IActionResult GetDept()
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var allDept = db.Departments.Select(x => new
                    {
                        x.Id,
                        x.Name
                    }).ToList();

                    return Ok(allDept);
                }
                catch (Exception ex)
                {
                    return StatusCode(401, $"Cannot create, {ex.Message}");
                }
            }
        }

        [HttpGet("GetDeptLoc")]
        public IActionResult GetDeptLoc(int departmentId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var allDept = db.Departments.Select(x => new
                    {
                        x.Id,
                        x.Name
                    }).ToList();

                    return Ok(allDept);
                }
                catch (Exception ex)
                {
                    return StatusCode(401, $"Cannot create, {ex.Message}");
                }
            }
        }

        [HttpPost("CreateAsset")]
        public IActionResult CreateAsset([FromBody]
           CreateAsset createAsset
        )
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var anyExistingAsset = db.Assets
                        .Any(x => x.AssetName == createAsset.AssetName && x.DepartmentLocationId == createAsset.DeptLocId);
                    if (anyExistingAsset)
                    {
                        return StatusCode(401, "Existing name in same location in db, cannot add.");
                    }

                    // Step 1: Parse the warrantyDate string into DateOnly (nullable)
                    DateOnly? parsedWarrantyDate = null;
                    if (!string.IsNullOrEmpty(createAsset.WarrantyDate))
                    {
                        if (DateOnly.TryParseExact(createAsset.WarrantyDate, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateOnly parsedDate))
                        {
                            parsedWarrantyDate = parsedDate; // Successfully parsed
                        }
                        else
                        {
                            return StatusCode(401, "Invalid warranty date format. Expected format is dd/MM/yyyy.");
                        }
                    }

                    // Step 1: Create Asset
                    Asset newAsset = new Asset()
                    {
                        AssetSn = createAsset.AssetSn,
                        AssetName = createAsset.AssetName,
                        DepartmentLocationId = createAsset.DeptLocId,
                        EmployeeId = createAsset.EmpId,
                        AssetGroupId = createAsset.AsGrpId,
                        Description = createAsset.Description,
                        WarrantyDate = parsedWarrantyDate ?? null
                    };
                    Console.WriteLine($"created details: {newAsset.Id}, {newAsset.AssetSn},{newAsset.AssetName},{newAsset.DepartmentLocationId},{newAsset.EmployeeId},{newAsset.AssetGroupId},{newAsset.Description},{newAsset.WarrantyDate}");

                    db.Assets.Add(newAsset);
                    db.SaveChanges();

                    var addedAssetId = newAsset.Id;

                    return Ok(addedAssetId);
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Cannot create asset: {ex.InnerException?.Message ?? ex.Message}");
                }
            }
        }

        [HttpPost("UploadAssetImages")]
        public IActionResult UploadAssetImages([FromBody] AssetPhotoView photos)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    Console.WriteLine($"newly created assetId: {photos.AssetId},images: {photos.Images}");
                    if (photos.Images != null && photos.Images.Count > 0)
                    {
                        foreach (var base64Photo in photos.Images)
                        {
                            // Decode Base64 string into a byte array
                            var photoBytes = Convert.FromBase64String(base64Photo);

                            var assetPhoto = new AssetPhoto
                            {
                                AssetId = photos.AssetId,
                                AssetPhoto1 = photoBytes // Storing as varbinary(max)
                            };

                            db.AssetPhotos.Add(assetPhoto);
                            db.SaveChanges();
                        }
                    }

                    db.SaveChanges();
                    return Ok("Uploaded image successfully");
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Cannot Upload image: {ex.Message}");
                }
            }
        }


        [HttpGet("GetLastAssetSN")]
        public IActionResult GetLastAssetSN(int deptId, int assetGrpId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    // First, fetch all relevant assets into memory
                    var assetSns = db.Assets
                        .Where(a => a.DepartmentLocationId == deptId && a.AssetGroupId == assetGrpId)
                        .Select(a => a.AssetSn)
                        .ToList();  // This brings the data into memory

                    // Then perform the string manipulation and parsing in memory
                    int lastSerialNumber = assetSns
                        .Select(sn => int.Parse(sn.Split('/').Last()))  // Now we can safely parse in-memory
                        .OrderByDescending(sn => sn)
                        .FirstOrDefault();

                    return Ok(lastSerialNumber);  // Return the last used serial number or 0 if none exist
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Internal server error: {ex.Message}");
                }
            }
        }

        [HttpGet("GetAssetDetails")]
        public IActionResult GetAssetDetails(int assetId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var existingAsset = db.Assets.Where(x => x.Id == assetId)
                        .Select(x => new
                        {
                            x.Id,
                            x.AssetName,
                            departmentName = x.DepartmentLocation.Department.Name,
                            locationName = x.DepartmentLocation.Location.Name,
                            assetGroupName = x.AssetGroup.Name,
                            employeeName = x.Employee.FirstName,
                            x.AssetSn,
                            x.Description,
                            x.WarrantyDate,
                            departmentId = x.DepartmentLocation.Department.Id,
                            assetGroupId = x.AssetGroup.Id,
                            employeeId = x.Employee.Id,
                            deptLocId = x.DepartmentLocationId,
                        })
                        .FirstOrDefault();
                    return Ok(existingAsset);
                }
                catch (Exception ex)
                {
                    return StatusCode(401, "Cannot fetch details");
                }
            }
        }

        [HttpGet("GetAssetDetailImage")]
        public IActionResult GetAssetDetailImage(int assetId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    var existingImages = db.AssetPhotos.Any(x => x.AssetId == assetId);

                    if (existingImages)
                    {
                        var allImages = db.AssetPhotos.Where(x => x.AssetId == assetId).Select(x => new
                        {
                            x.Id,
                            x.AssetId,
                            Images = new List<string> { Convert.ToBase64String(x.AssetPhoto1) }
                        }).ToList();
                        return Ok(allImages);
                    }

                    return StatusCode(401, "No Images for event");
                }
                catch (Exception ex)
                {
                    return StatusCode(401, "Cannot fetch details");
                }
            }
        }

        [HttpPut("UpdateAsset")]
        public IActionResult UpdateEdit([FromBody] AssetUpdatePayload assetUpdatePayload)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    Console.WriteLine($"id: {assetUpdatePayload.AssetId}, AssetName: {assetUpdatePayload.AssetName}, EmpId: {assetUpdatePayload.EmpId}, Description: {assetUpdatePayload.Description}, WarrantyDate: {assetUpdatePayload.WarrantyDate}");
                    // Step 1: Fetch the existing asset from the database
                    var existingAsset = db.Assets.FirstOrDefault(a => a.Id == assetUpdatePayload.AssetId);
                    if (existingAsset == null)
                    {
                        Console.WriteLine("Asset not found");
                        return NotFound("Asset not found.");
                    }

                    // Step 2: Check if another asset with the same name exists in the same location
                    var duplicateAsset = db.Assets
                        .FirstOrDefault(a => a.AssetName == assetUpdatePayload.AssetName && a.DepartmentLocationId == existingAsset.DepartmentLocationId && a.Id != assetUpdatePayload.AssetId);

                    if (duplicateAsset != null)
                    {
                        Console.WriteLine("An asset with the same name already exists in this location.");
                        return BadRequest("An asset with the same name already exists in this location.");
                    }

                    // Step 3: Update asset details except the read-only fields (Location, Department, Asset Group)
                    existingAsset.AssetName = assetUpdatePayload.AssetName;
                    existingAsset.EmployeeId = assetUpdatePayload.EmpId;
                    existingAsset.Description = assetUpdatePayload.Description;

                    DateOnly? parsedWarrantyDate = null;
                    if (!string.IsNullOrEmpty(assetUpdatePayload.WarrantyDate))
                    {
                        if (DateOnly.TryParseExact(assetUpdatePayload.WarrantyDate, "dd/MM/yyyy", null, System.Globalization.DateTimeStyles.None, out DateOnly parsedDate))
                        {
                            parsedWarrantyDate = parsedDate; // Successfully parsed
                            existingAsset.WarrantyDate = parsedWarrantyDate;
                        }
                        else
                        {
                            Console.WriteLine("Invalid warranty date format. Expected format is dd/MM/yyyy.");
                            return StatusCode(401, "Invalid warranty date format. Expected format is dd/MM/yyyy.");
                        }
                    }

                    // Step 5: Save the changes to the database
                    db.SaveChanges();

                    Console.WriteLine("Asset updated successfully.");
                    return Ok("Asset updated successfully.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.ToString());
                    return StatusCode(401, $"Cannot update asset. Error: {ex.Message}");
                }
            }
        }

        [HttpDelete("DeleteOldImages")]
        public IActionResult DeleteOldImage(int assetId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    if (db.AssetPhotos.Any(x => x.AssetId == assetId))
                    {
                        var existingAsset = db.AssetPhotos.Where(x => x.AssetId == assetId).ToList();
                        db.AssetPhotos.RemoveRange(existingAsset);
                    }
                    return Ok("Deleted Old records.");
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Cannot update asset. Error: {ex.Message}");
                }
            }
        }

        [HttpGet("GetRecordsByOldest")]
        public IActionResult GetTransferRecords(int assetId)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    if (db.AssetTransferLogs.Any(x=> x.AssetId == assetId))
                    {
                        var records = db.AssetTransferLogs.Where(x => x.AssetId == assetId).Select(x => new
                        {
                            x.TransferDate,
                            OldDepartment = x.FromDepartmentLocation.Location.Name,
                            OldAssetSn = x.FromAssetSn,
                            NewDepartment = x.ToDepartmentLocation.Location.Name,
                            NewAssetSn = x.ToAssetSn,
                        }).OrderBy(x=> x.TransferDate)
                        .ToList();
                        return Ok(records);
                    }
                    else
                    {
                        return Ok("No history");
                    }
                } catch (Exception ex)
                {
                    return StatusCode(500, $"Error moving asset and recording transfer: {ex.Message}");
                }
            }
        }

        [HttpPost("MoveAssetAndRecordTransfer")]
        public IActionResult MoveAssetAndRecordTransfer([FromBody] AssetTransferRequest moveRequest)
        {
            using (Wsc2019Session1Context db = new Wsc2019Session1Context())
            {
                try
                {
                    // Step 1: Fetch the existing asset
                    var existingAsset = db.Assets.FirstOrDefault(a => a.Id == moveRequest.AssetId);
                    if (existingAsset == null)
                    {
                        return NotFound("Asset not found.");
                    }

                    // Step 2: Check if another asset with the same new serial number exists in the new department
                    var duplicateAsset = db.Assets
                        .FirstOrDefault(a => a.AssetSn == moveRequest.NewAssetSn && a.DepartmentLocationId == moveRequest.NewDeptLocId);

                    if (duplicateAsset != null)
                    {
                        return BadRequest("An asset with the same serial number already exists in this department.");
                    }

                    DateOnly currentDate = DateOnly.FromDateTime(DateTime.Now);

                    // Step 3: Record the transfer
                    var transfer = new AssetTransferLog
                    {
                        AssetId = moveRequest.AssetId,
                        TransferDate = currentDate,
                        FromDepartmentLocationId = moveRequest.OldDeptLocId,
                        FromAssetSn = moveRequest.OldAssetSn,
                        ToDepartmentLocationId = moveRequest.NewDeptLocId,
                        ToAssetSn = moveRequest.NewAssetSn
                    };
                    db.AssetTransferLogs.Add(transfer);

                    // Step 4: Update asset details to reflect the new department and new serial number
                    existingAsset.DepartmentLocationId = moveRequest.NewDeptLocId;
                    existingAsset.AssetSn = moveRequest.NewAssetSn;
                    db.SaveChanges();

                    return Ok("Asset moved and transfer recorded successfully.");
                }
                catch (Exception ex)
                {
                    return StatusCode(500, $"Error moving asset and recording transfer: {ex.Message}");
                }
            }
        }





    }
}
