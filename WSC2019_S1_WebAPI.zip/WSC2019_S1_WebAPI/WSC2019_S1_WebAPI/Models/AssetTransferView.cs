﻿using System;
using System.Collections.Generic;

namespace WSC2019_S1_WebAPI.Models;

public class AssetTransferRequest
{
    public int AssetId { get; set; }
    public string OldAssetSn { get; set; }
    public int OldDeptLocId { get; set; } 
    public string NewAssetSn { get; set; }
    public int NewDeptLocId { get; set; }
}
