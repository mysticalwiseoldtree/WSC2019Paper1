﻿using System;
using System.Collections.Generic;

namespace WSC2019_S1_WebAPI.Models;

public partial class AssetGroup
{
    public long Id { get; set; }

    public string Name { get; set; } = null!;

    public virtual ICollection<Asset> Assets { get; set; } = new List<Asset>();
}
