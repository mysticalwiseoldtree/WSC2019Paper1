﻿using System;
using System.Collections.Generic;

namespace WSC2019_S1_WebAPI.Models;

public class AssetPhotoView
{

    public int AssetId { get; set; }
    public List<string> Images { get; set; }
    
}
