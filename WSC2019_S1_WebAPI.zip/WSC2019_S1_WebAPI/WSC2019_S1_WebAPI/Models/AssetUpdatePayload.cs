﻿using System;
using System.Collections.Generic;

namespace WSC2019_S1_WebAPI.Models;

public class AssetUpdatePayload
{

    public int AssetId { get; set; }
    public string AssetName { get; set; }
    public int EmpId { get; set; }
    public string Description { get; set; }
    public string? WarrantyDate { get; set; }
}
