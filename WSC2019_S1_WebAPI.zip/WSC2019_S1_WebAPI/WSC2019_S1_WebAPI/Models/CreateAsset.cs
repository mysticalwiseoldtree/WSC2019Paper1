﻿using System;
using System.Collections.Generic;

namespace WSC2019_S1_WebAPI.Models;

public class CreateAsset
{
    public string AssetSn { get; set; }
           public string AssetName { get; set; }
            public int DeptLocId { get; set; }
            public int EmpId { get; set; }
            public int AsGrpId { get; set; }
            public string Description { get; set; }
            public string? WarrantyDate { get; set; }

}
